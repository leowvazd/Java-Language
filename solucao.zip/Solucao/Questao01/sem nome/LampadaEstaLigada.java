

class LampadaEstaLigada extends Exception {
	private static final long serialVersionUID = 1L;

	public LampadaEstaLigada() {
		super("A lampada ja esta ligada.");
	}

}
