/* 
 * IMPORTANTE: NAO ALTERE ESTE ARQUIVO
 */
package relatorio;

public interface PluginTexto {
    String aplicar(String texto);
}