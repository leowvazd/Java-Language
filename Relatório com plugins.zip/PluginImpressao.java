/* 
 * IMPORTANTE: NAO ALTERE ESTE ARQUIVO
 */
package relatorio;

public interface PluginImpressao {
    void imprimir(Relatorio r);
}